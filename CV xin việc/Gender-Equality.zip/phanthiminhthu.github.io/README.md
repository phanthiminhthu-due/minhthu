# phanthiminhthu.github.io<html>

<head>
    <title>CV_Phan Thị Minh Thu</title>
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <link rel="stylesheet" href="../css/cv.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>

<body>
    <div class="cv">
        <div class="cv_left">
            <div class="cv_profile">
                <img src="../images/anhtt.jpg">
            </div>
            <div class="cv_content">
                <div class="cv_item cv_info">
                    <div class="title">
                        <p class="bold" style="text-align: center; font-size: 20px;font-weight: bold"> Phan Thị Minh Thu</p>
                        <p class="regular" style="text-align: center; font-size: 14px">_Tester_</p>
                        <div style="color: #b1eaff;text-align: center">Là một người vui tính, hoà đồng với mọi người luôn nhiệt tình trong công việc. Mong muốn được học hỏi kinh nghiệm ở môi trường làm việc chuyên nghiệp, năng động. Có cơ hội thăng tiến cao, thành công trong công việc
                        </div>
                    </div>


                    <ul>
                        <li>
                            <div class="icon"><i class="fas fa-transgender-alt"></i></div>
                            <div class="data">Nữ</div>
                            &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<div class="icon"><i class="fas fa-calendar-alt"></i></div>
                            <div class="data">26 / 09 / 1999</div>

                        </li>
                        <li>
                            <div class="icon"><i class="fas fa-map-signs"></i></div>
                            <div class="data">K55 / 19, Ngũ Hành Sơn<br /> Đà Nẵng</div>
                        </li>
                        <li>
                            <div class="icon"><i class="fas fa-mobile-alt" aria-hidden="true"></i></div>
                            <div class="data"> 0947 134 080</div>
                        </li>
                        <li>
                            <div class="icon"><i class="fas fa-envelope" aria-hidden="true"></i></div>
                            <div class="data">minhthugiomy@gmail.com</div>
                        </li>
                        <li>
                            <div class="icon"><i class="fab fa-weebly" aria-hidden="true"></i></div>
                            <div class="data">phanthiminhthu.github.io</div>
                        </li>
                    </ul>
                </div>
                <div class="cv_item cv_skills">
                    <div class="title">
                        <p class="bold"> Kỹ năng cứng</p>

                    </div>
                    <ul>
                        <li>
                            <div class="skill_name" style="color: yellow">
                                HTML
                            </div>
                            <div class="skill_progress">
                                <span style=" width:70%;"></span>
                            </div>
                            <div class="skill_per" style="color: yellow">
                                70%
                            </div>

                        </li>

                        <li>
                            <div class="skill_name" style="color: yellow">
                                CSS
                            </div>
                            <div class="skill_progress">
                                <span style=" width:60%;"></span>
                            </div>
                            <div class="skill_per" style="color: yellow">
                                60%
                            </div>

                        </li>

                        <li>
                            <div class="skill_name" style="color: yellow">
                                JS
                            </div>
                            <div class="skill_progress">
                                <span style=" width:50%;"></span>
                            </div>
                            <div class="skill_per" style="color: yellow">
                                50%
                            </div>

                        </li>
                        <li>
                            <div class="skill_name" style="color: yellow">
                                Bootstrap
                            </div>
                            &nbsp;&nbsp;<div class="skill_progress">
                                <span style=" width:50%;"></span>
                            </div>
                            <div class="skill_per" style="color: yellow">
                                50%
                            </div>

                        </li>

                        <li>
                            <div class="skill_name" style="color: yellow"> Microsoft

                            </div>&nbsp;&nbsp;
                            <div class="skill_progress">
                                <span style=" width:80%;"></span>
                            </div>
                            <div class="skill_per" style="color: yellow">
                                80%
                            </div>
                        </li>

                    </ul>

                </div>
                <div class="cv_item cv_skills">
                    <div class="title">
                        <p class="bold"> Kỹ năng mềm</p>

                    </div>
                    <ul>
                        <li>Kỹ năng làm việc nhóm</li>
                        <li>Kỹ năng thuyết trình</li>
                        <li>Kỹ năng giao tiếp</li>
                        <li>Thái độ làm việc cao</li>
                    </ul>
                </div>
                <div class="cv_item cv_skills">
                    <div class="title">
                        <p class="bold"> Ngôn ngữ</p>
                    </div>
                    <ul>

                        <li>
                            <div class="skill_name" style="color: yellow">
                                Tiếng Anh
                            </div>&nbsp;&nbsp;
                            <div class="skill_progress">
                                <span style=" width:60%;"></span>
                            </div>
                            <div class="skill_per" style="color: yellow">
                                60%
                            </div>

                        </li>

                        <p style="color: #b1eaff">Trình độ 5.0 ielts </p>
                    </ul>
                </div>
            </div>
        </div>
        <div class="cv_right">

            <div class="cv_item cv_education">
                <div class="title">
                    <p class="bold">Trình độ học vấn</p>
                </div>
                <ul>
                    <li>
                        <div class="date" class="date" style="color: red">08 / 2017 - 01 / 2020</div>
                        <div class="info">
                            <p class="semi-bold">Đại Học Kinh Tế - Đại Học Đà Nẵng</p>
                            <p><span style="font-weight: bold">Chuyên ngành:</span> Thương mại điện tử</p>
                            <p><span style="font-weight: bold">Trình độ:</span> Sinh viên năm 4</p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="cv_item cv_work">
                <div class="title">
                    <p class="bold">Kinh nghiệm</p>
                </div>
                <ul>
                    <li>
                        <div class="date" class="date" style="color: red">08 / 2018 - 10 / 2019</div>
                        <div class="info">
                            <p class="semi-bold">Nhân viên Marketing Online tại công ty CityA</p>
                            <p>+ Nhân viên content marketing, xây dựng, quản lý và phát triển fanpage về Bất động sản.
                                <br>+ Thiết kế và xây dựng hình ảnh, video.
                            </p>
                        </div>
                        <br>
                    </li>
                    <li>
                        <div class="date" class="date" style="color: red">05 / 2019</div>
                        <div class="info">
                            <p class="semi-bold">Chương trình "Kết nối hàng Việt Đà Nẵng 2019" </p>
                            <p>+ Là cộng tác viên trong vai trò thành viên ban tổ chức của chương trình hội chợ kết nối hàng Việt do UBND thành phố Đà Nẵng tổ chức cùng với các doanh nghiệp.
                            </p>
                        </div>
                        <br>
                    </li>
                    <li>
                        <div class="date" class="date" style="color: red">11 / 2019 - 08 / 2020</div>
                        <div class="info">
                            <p class="semi-bold">Freelancer về thiết kế front-end</p>
                            <p>+ Chủ yếu sử dụng các ngôn ngữ html, css,javascript, boostrap để thiết kế giao diện website cao nước Atiso,..<br>
                                + Tự thiết kế cv cho bản thân để xin việc.
                            </p>
                        </div>
                    </li><br>
                    <li>
                        <div class="date" class="date" style="color: red">09 / 2020 - 10 / 2020
                        </div>
                        <div class="info">
                            <p class="semi-bold">Khoá đào tạo testing</p>
                            <p>Tham gia khoá học testing tại Codegym trong vòng 2 tháng và được thực hiện testcase thực tế cơ bản.</p>
                        </div>
                    </li>

                </ul>
            </div>

            <div class="cv_item cv_education">
                <div class="title">
                    <p class="bold">Các hoạt động tham gia</p>
                </div>
                <ul>
                    <li>
                        <div class="date" style="color: red">06 / 2018 - 10 / 2019</div>
                        <div class="info">
                            <p class="semi-bold">Thành viên Sgroup</p>
                            <p>+ Tham gia các buổi đào tạo về kiến thức SEO, marketing online,..
                                <br>+ Kinh nghiệm sale(tham gia bán hoa vào các ngày lễ, có kinh nghiệm 6 tháng bán hàng trực tiếp),..
                                <br> + Tham gia các hoạt động tập thể
                            </p>
                        </div>
                    </li><br>
                    <li>
                        <div class="date" class="date" style="color: red">11 / 2019
                        </div>
                        <div class="info">
                            <p class="semi-bold">Chiến dịch tình nguyện đông "Xuân đông đầy" cùng câu lạc bộ I-design</p>
                            <p>Tham gia hoạt động bán hàng gây quỹ ủng hộ cho các gia đình khó khăn ở Duy Xuyên-Quảng Nam.
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="cv_item cv_hobby">
                <div class="title">
                    <p class="bold">Sở thích</p>
                </div>
                <ul>
                    <li><i class="fas fa-book" aria-hidden="true"></i></li>
                    <li><i class="fas fa-gamepad" aria-hidden="true"></i></li>
                    <li><i class="fas fa-music" aria-hidden="true"></i></li>
                    <li><i class="fas fa-suitcase-rolling" aria-hidden="true"></i></li>
                </ul><br>
                <span style="float: right; color: gainsboro;font-size: 20px">MINH THU</span>
            </div>
        </div>
    </div>
</body></html>
